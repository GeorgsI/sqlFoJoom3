DROP TABLE IF EXISTS `#__deputy`;
DROP TABLE IF EXISTS `#__okrug`;
